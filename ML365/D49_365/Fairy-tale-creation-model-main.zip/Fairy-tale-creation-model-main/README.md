# Fairy-tale-creation-model
If you give the opening sentence of a fairy tale, it is a model that creates the continuation of the story.
